"""Property exercises"""


class Circle:
    """Circle with radius, area, etc."""


class Vector:
    """Class representing a 3 dimensional vector."""


class Person:
    """Person with first and last name."""
